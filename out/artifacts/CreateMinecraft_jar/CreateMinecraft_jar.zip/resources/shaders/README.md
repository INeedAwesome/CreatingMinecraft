///////////////////////////////////
// BE CAREFUL
///////////////////////////////////

This program uses these shaders when running this program, 
modifying or deleting will have BIG effects.

Modifying the fragmentShader.txt or vertexShader.txt is there to experiment with.

//////////////////////////////////////////
//  MODIFY AT YOUR OWN RISK!!
//////////////////////////////////////////